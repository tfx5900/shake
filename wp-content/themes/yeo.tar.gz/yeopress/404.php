<?php get_header(); ?>
	<div id="page-content" class="nav-menu wrapper">
		<h1>Error 404</h1>
	</div>
<?php get_footer(); ?>
