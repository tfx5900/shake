<?php get_header(); ?>
<div id="page-content">
	<?php get_template_part('loop', 'home'); ?>
</div>
<?php get_footer(); ?>
