<?php
/*
Template Name: Expertis Page
*/
?>
<?php get_header(); ?>
<div class="page expertis-page">
  <div class="wrapper expertis-list">
    <div class="content">
      <h1>At shakes we can provide a variety of resources
  to suit your needs</h1>
    </div>

    <div class="icons">
      <a href="#branding"></a>
      <a href="#industrial"></a>
      <a href="#engineering"></a>
      <a href="#packaging"></a>
      <div class="clear"></div>
    </div>

  </div>

  <div class="expertis-full-list">
    <div class="expertis" id="branding">
      <h1>Branding</h1>
      <h2>Lorem ipsum dolor sit amet, consectetur adipiscing
        elit. Quisque eget nisi et ipsum viverra euismod
        pretium ac nisl. Curabitur sagittis, nunc consequat
        iaculis iaculis, urna sapien varius nunc
      </h2>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque eget nisi et ipsum viverra euismod pretium ac nisl. Curabitur sagittis, nunc consequat iaculis iaculis, urna sapien varius nunc, ac scelerisque quam turpis quis velit. Quisque nec mi tristique, suscipit mauris id, gravida dolor. Sed sollicitudin nulla vel lorem imperdiet, eget tempor ligula aliquet. Ut tellus quam, rhoncus sit amet auctor et, varius non lorem. Integer nunc dui, congue quis rhoncus at, molestie eget lacus. Ut sodales, tortor non suscipit malesuada, magna lacus mattis felis, vulputate fringilla tellus elit nec mauris. Donec leo nisl, pulvinar at velit eu, hendrerit rutrum quam. In eu venenatis ipsum, rhoncus tincidunt eros. </p>
      <span class="big-close-button"></span>
    </div>
    <div class="expertis" id="industrial">
      <h1>Industrial</h1>
      <h2>Lorem ipsum dolor sit amet, consectetur adipiscing
        elit. Quisque eget nisi et ipsum viverra euismod
        pretium ac nisl. Curabitur sagittis, nunc consequat
        iaculis iaculis, urna sapien varius nunc
      </h2>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque eget nisi et ipsum viverra euismod pretium ac nisl. Curabitur sagittis, nunc consequat iaculis iaculis, urna sapien varius nunc, ac scelerisque quam turpis quis velit. Quisque nec mi tristique, suscipit mauris id, gravida dolor. Sed sollicitudin nulla vel lorem imperdiet, eget tempor ligula aliquet. Ut tellus quam, rhoncus sit amet auctor et, varius non lorem. Integer nunc dui, congue quis rhoncus at, molestie eget lacus. Ut sodales, tortor non suscipit malesuada, magna lacus mattis felis, vulputate fringilla tellus elit nec mauris. Donec leo nisl, pulvinar at velit eu, hendrerit rutrum quam. In eu venenatis ipsum, rhoncus tincidunt eros. </p>
      <span class="big-close-button"></span>
    </div>
    <div class="expertis" id="engineering">
      <h1>Engineering</h1>
      <h2>Lorem ipsum dolor sit amet, consectetur adipiscing
        elit. Quisque eget nisi et ipsum viverra euismod
        pretium ac nisl. Curabitur sagittis, nunc consequat
        iaculis iaculis, urna sapien varius nunc
      </h2>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque eget nisi et ipsum viverra euismod pretium ac nisl. Curabitur sagittis, nunc consequat iaculis iaculis, urna sapien varius nunc, ac scelerisque quam turpis quis velit. Quisque nec mi tristique, suscipit mauris id, gravida dolor. Sed sollicitudin nulla vel lorem imperdiet, eget tempor ligula aliquet. Ut tellus quam, rhoncus sit amet auctor et, varius non lorem. Integer nunc dui, congue quis rhoncus at, molestie eget lacus. Ut sodales, tortor non suscipit malesuada, magna lacus mattis felis, vulputate fringilla tellus elit nec mauris. Donec leo nisl, pulvinar at velit eu, hendrerit rutrum quam. In eu venenatis ipsum, rhoncus tincidunt eros. </p>
      <span class="big-close-button"></span>
    </div>
    <div class="expertis" id="packaging">
      <h1>Packaging</h1>
      <h2>Lorem ipsum dolor sit amet, consectetur adipiscing
        elit. Quisque eget nisi et ipsum viverra euismod
        pretium ac nisl. Curabitur sagittis, nunc consequat
        iaculis iaculis, urna sapien varius nunc
      </h2>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque eget nisi et ipsum viverra euismod pretium ac nisl. Curabitur sagittis, nunc consequat iaculis iaculis, urna sapien varius nunc, ac scelerisque quam turpis quis velit. Quisque nec mi tristique, suscipit mauris id, gravida dolor. Sed sollicitudin nulla vel lorem imperdiet, eget tempor ligula aliquet. Ut tellus quam, rhoncus sit amet auctor et, varius non lorem. Integer nunc dui, congue quis rhoncus at, molestie eget lacus. Ut sodales, tortor non suscipit malesuada, magna lacus mattis felis, vulputate fringilla tellus elit nec mauris. Donec leo nisl, pulvinar at velit eu, hendrerit rutrum quam. In eu venenatis ipsum, rhoncus tincidunt eros. </p>
      <span class="big-close-button"></span>
    </div>
  </div>
</div>
<?php get_footer(); ?>
