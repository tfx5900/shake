<?php
/*
Template Name: Careers Page
*/
?>
<?php get_header(); ?>
<?php if (have_posts()) the_post();?>
<div class="page careers-page wrapper content">
  <div class="banner">
    <img src="<?php bloginfo('template_url');?>/images/careers-banner.jpg" alt="">
  </div>
  <h1 class="red">Be a Shakes</h1>
  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin nec libero mauris.
Donec consequat malesuada eros in volutpat. Mauris feugiat elit id convallis dictum.
Pellentesque suscipit lorem eu hendrerit consectetur.</p>
  <h1 class="red">Who we're looking for</h1>
  <div class="job-list">
    <a class="job" href="#job-1">
      Graphic Designer
      <span>1</span>
    </a>
    <a class="job" href="#">
      Industrial Designer
      <span>5</span>
    </a>
    <a class="job" href="#">
      Graphic Designer
      <span>1</span>
    </a>
    <a class="job" href="#">
      Graphic Designer
      <span>1</span>
    </a>
    <a class="job" href="#">
      Graphic Designer
      <span>1</span>
    </a>
    <div class="clear"></div>
  </div>
  <div class="note">
    <p>Please accumsan, turpis vel lacinia vestibulum, quam justo mollis  turpis  vel lacinia vestibulum, quam justo mollis.</p>
  </div>

</div>
<div class="job-full-list">
  <div class="job" id="job-1">
    <h2 class="red">Position</h2>
    <h1>GRAPHIC DESIGNER</h1>
    <div class="content">
      <p>
      WHAT YOU’LL BE RESONSIBLE FOR <br>
• Lorem ipsum dolor sit amet, consectetur adipiscing <br>
elit. Etiam vel felis ante. Donec accumsan, turpis  vel lacinia <br>
• Vestibulum, quam justo mollis. Lorem ipsum dolor sit amet, consectetur adipiscing <br>
elit. Etiam vel felis ante. Donec accumsan, turpis  vel lacinia <br>
• Eestibulum, quam justo mollis.
</p>

<p>
WHAT WE NEED <br>
• Lorem ipsum dolor sit amet, consectetur adipiscing <br>
• Bestibulum, quam justo mollis. <br>
• Lorem ipsum dolor sit <br>
• Lorem ipsum dolor sit amet, consectetur <br>
• Bestibulum, quam justo mollis. <br>
• Lorem ipsum dolor sit amet, consectetur
</p>

<p>
Email: <a href="mailto:infor@shakesbkk.com">infor@shakesbkk.com</a>
</p>
    </div>
    <span class="close-button"></span>
  </div>
</div>
<?php get_footer(); ?>
