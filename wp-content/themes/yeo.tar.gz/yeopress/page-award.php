<?php
/*
Template Name: Award Page
*/
?>
<?php get_header(); ?>
<?php if (have_posts()) the_post();?>
<div class="page award-page wrapper">
  <div class="content">
    <h1>shakes’s <span class='red'>Award</span></h1>
    <div class="half">
      <?php the_content(); ?>
    </div>

  </div>
  <div class="award-list">
    <a href="/award-1">
      <img src="<?php bloginfo('template_url');?>/images/sample/award1.png" alt="">
    </a>
    <a href="#award-2">
      <img src="<?php bloginfo('template_url');?>/images/sample/award2.png" alt="">
    </a>
  </div>
</div>
<?php get_footer(); ?>
