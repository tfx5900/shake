<?php
/*
Template Name: Work Page
*/
?>
<?php get_header(); ?>
<div class="page work-page">
  <div class="nav-menu">
    <a href="#graphic-design">graphic design</a>
    <a href="#industrial-design">industrial design</a>
    <a href="#branding-design">branding design</a>
    <a href="#packaging-design">packaging design</a>
  </div>
  <div class="works">
    <a href="/work-1" class="work graphic-design">
      <img src="<?php bloginfo('template_url');?>/images/sample/work1.png" alt="">
    </a>
    <a href="#work1" class="work industrial-design">
      <img src="<?php bloginfo('template_url');?>/images/sample/work1.png" alt="">
    </a>
    <a href="#work1" class="work graphic-design">
      <img src="<?php bloginfo('template_url');?>/images/sample/work1.png" alt="">
    </a>
    <a href="#work1" class="work industrial-design">
      <img src="<?php bloginfo('template_url');?>/images/sample/work1.png" alt="">
    </a>
    <a href="#work1" class="work branding-design">
      <img src="<?php bloginfo('template_url');?>/images/sample/work1.png" alt="">
    </a>
    <a href="#work1" class="work packaging-design">
      <img src="<?php bloginfo('template_url');?>/images/sample/work1.png" alt="">
    </a>
    <a href="#work1" class="work packaging-design">
      <img src="<?php bloginfo('template_url');?>/images/sample/work1.png" alt="">
    </a>
    <a href="#work1" class="work graphic-design">
      <img src="<?php bloginfo('template_url');?>/images/sample/work1.png" alt="">
    </a>
    <a href="#work1" class="work graphic-design">
      <img src="<?php bloginfo('template_url');?>/images/sample/work1.png" alt="">
    </a>
    <a href="#work1" class="work graphic-design">
      <img src="<?php bloginfo('template_url');?>/images/sample/work1.png" alt="">
    </a>
    <div class="clear"></div>
  </div>
</div>
<?php get_footer(); ?>
