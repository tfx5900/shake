<?php
/*
Template Name: About Page
*/
?>
<?php get_header(); ?>
<div class="wrapper page about-page">
  <div class="nav-menu">
    <ul>
      <li><a href="#about" class="selected">about shakes</a></li>
      <li><a href="#story">shakes's story</a></li>
      <li><a href="#philosophy">shakes philosophy</a></li>
      <li><a href="#the-shakers">the shakers</a></li>
      <li><a href="#our-believers">our believers</a></li>

    </ul>
    <div class="clear"></div>
  </div>
  <div class="tabs">
    <div class="tab" id="about">
      <div class="content">
        <?php the_field('about');?>
      </div>
    </div>
    <div class="tab" id="story">
      <div class="content">
        <?php the_field('story');?>
      </div>
    </div>
    <div class="tab" id="philosophy">
      <div class="content">
        <?php the_field('philosophy');?>
      </div>
    </div>
    <div class="tab" id="our-believers">
      <div class="content">
        <?php the_field('our-believers');?>
      </div>
    </div>
  </div>


</div>

<div class="tab hide" id="the-shakers">
  <div class="content wrapper">
    <h1 class="red">
      Hi! We are the shakes team <br>
      Nice to meet you :)
    </h1>
  </div>

  <div class="people-list">
    <a href="#person1" class="person">
      <img src="<?php bloginfo('template_url');?>/images/sample/person1.png" alt="">
    </a>
    <a href="#person2" class="person">
      <img src="<?php bloginfo('template_url');?>/images/sample/person1.png" alt="">
    </a>
    <a href="#person1" class="person">
      <img src="<?php bloginfo('template_url');?>/images/sample/person1.png" alt="">
    </a>
    <a href="#person1" class="person">
      <img src="<?php bloginfo('template_url');?>/images/sample/person1.png" alt="">
    </a>
    <a href="#person1" class="person">
      <img src="<?php bloginfo('template_url');?>/images/sample/person1.png" alt="">
    </a>
    <a href="#person1" class="person">
      <img src="<?php bloginfo('template_url');?>/images/sample/person1.png" alt="">
    </a>
    <a href="#person1" class="person">
      <img src="<?php bloginfo('template_url');?>/images/sample/person1.png" alt="">
    </a>
    <div class="clear"></div>
  </div>

  <div class="people-full-list">
    <div class="person wrapper" id="person1">
      <div class="left photo">
        <img src="<?php bloginfo('template_url');?>/images/sample/person1-full.png" alt="">
      </div>
      <div class="right description content">
        <h2>Prompong Hakk</h2>
        <h3>Co-Founder, MD and Creative Director</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing
elit. Etiam vel felis ante. Donec accumsan, turpis
vel lacinia vestibulum, quam justo mollis sapien,
eleifend volutpat velit mi euismod elit. </p>
      </div>
      <span class="close-button"></span>
      <div class="clear"></div>
    </div>

    <div class="person wrapper" id="person2">
      <div class="left photo">
        <img src="<?php bloginfo('template_url');?>/images/sample/person1-full.png" alt="">
      </div>
      <div class="right description content">
        <h2>Prompong 2</h2>
        <h3>Co-Founder, MD and Creative Director</h3>
        <p>Lorem ipsum dolor sit amet, consectetur adipiscing
elit. Etiam vel felis ante. Donec accumsan, turpis
vel lacinia vestibulum, quam justo mollis sapien,
eleifend volutpat velit mi euismod elit. </p>
      </div>
      <span class="close-button"></span>
      <div class="clear"></div>
    </div>
  </div>
</div>


<?php get_footer(); ?>
