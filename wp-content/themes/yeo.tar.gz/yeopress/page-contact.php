<?php
/*
Template Name: Contact Page
*/
?>
<?php get_header(); ?>
<?php if (have_posts()) the_post();?>
<div class="page contact-page wrapper">
  <div class="content">
    <div class="top">
      <h2>BANGKOK BRANCH</h2>
  ​
      <p>Oasis Pattanakarn, 358 Muangthong Village 2/3, Pattanakarn 53,
        Suanluang Bangkok 10250, Thailand</p>
      ​
      <p>E: info@shakesbkk.com <br>
        T: +66.2320.2889
        </p>​
      <h2>SHANGHAI BRANCH</h2>
      ​
      <p>Room 1703, No. 228 Xinjian Rd., Minhang Dis, Shanghai 201100, China</p>

      <p>T: +86-21-64880084​</p>

      <p>Maggie Wang, email: wang.m@shakesbkk.com​ <br>
        Jeff Zhang, email: zhang.j@shakesbkk.com​ <br>
        Ducati Ni, email: ni.d@shakesbkk.com
        </p>
    </div>
    <div class="bottom">
      <form action="">
        <input type="text" placeholder="Name" name="name">
        <input type="email" placeholder="Email" name='email'>
        <input type="text" placeholder="Subject" name="subject" class="no-border">
        <textarea name="message" placeholder="Message"></textarea>
        <input type="submit" value="Submit">
        <div class="clear"></div>
      </form>
    </div>
  </div>

</div>
<?php get_footer(); ?>
