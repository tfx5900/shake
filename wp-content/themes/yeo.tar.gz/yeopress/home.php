<?php get_header(); ?>
<div class="wrapper homepage">
  <h1></h1>
</div>
<?php get_footer(); ?>
